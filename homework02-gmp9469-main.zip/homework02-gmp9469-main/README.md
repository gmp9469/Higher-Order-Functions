gmp9469 Homework #02 - Higher Order Functions: Exercises and Processing Data
